<script src="<?= base_url('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js') ?>"></script>
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>

<script src="<?= base_url('assets/vendors/apexcharts/apexcharts.js') ?>"></script>
<script src="<?= base_url('assets/js/pages/dashboard.js') ?>"></script>

<script src="<?= base_url('assets/vendors/simple-datatables/simple-datatables.js') ?>"></script>

<script src="<?= base_url('assets/js/main.js') ?>"></script>
<script src="<?= base_url('assets/js/horizontal-layout.js') ?>"></script>