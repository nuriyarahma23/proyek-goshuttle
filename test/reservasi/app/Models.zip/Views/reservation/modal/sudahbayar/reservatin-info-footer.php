<button class="btn btn-primary" onclick="window.open('<?= base_url('pdfslipreservasi/'.$id) ?>', '', 'width=500,height=500')">
    <span class="d-none d-sm-block">Cetak Tiket</span>
</button>