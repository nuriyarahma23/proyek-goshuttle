<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cetak Manifest</title>
    <style>
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            margin: 1px;
        }

        body {
            font-family: "Tahoma", sans-serif
        }
    </style>
</head>

<body onload="window.print()">
    <div style="width: 300px; page-break-before: always">
        <div style="text-align: center; margin-top: 5px">
            <img src="<?php echo base_url('logo_go_2.png'); ?>" alt="logo" width="200px"><br>
            <small>#luxuryShuttleService</small>
        </div>
        <br>
        <h2>Manifest</h2>
        <table style="font-size: small">
            <tbody>
                <tr>
                    <td>No</td>
                    <td>: CHM-JTR-230720-0900-38164</td>
                </tr>
                <tr>
                    <td>Rute</td>
                    <td>: CHM - JTR </td>
                </tr>
                <tr>
                    <td>Tgl/Jam</td>
                    <td>: Kamis, 20 Jul 2023 / 09:00 </td>
                </tr>
                <tr>
                    <td>Sopir</td>
                    <td>: Iyan suryana </td>
                </tr>
                <tr>
                    <td>Mobil</td>
                    <td>: GS-103 / DK 7513 FA </td>
                </tr>
                <tr>
                    <td>BOP</td>
                    <td>: 468,000 </td>
                </tr>
                <tr>
                    <td>Pt. Kbrgktn</td>
                    <td>: CIHAMPELAS </td>
                </tr>
            </tbody>
        </table>
        <hr>
        <strong><small>PENUMPANG</small></strong>
        <table width="100%" style="font-size: small">
            <tbody>
                <tr style="font-weight: bold">
                    <td>Krs</td>
                    <td>Pnp</td>
                    <td>Tiket</td>
                    <td>Bayar</td>
                    <td>Harga</td>
                </tr>

                <tr>
                    <td>1</td>
                    <td>BU SRI HRD</td>
                    <td>Give Awa...</td>
                    <td>CASH PAY...</td>
                    <td align="right">0</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>AKBAR </td>
                    <td>Umum</td>
                    <td>BANK TRA...</td>
                    <td align="right">105,000</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>MAYA</td>
                    <td>Umum</td>
                    <td>BANK TRA...</td>
                    <td align="right">105,000</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>ANDIN</td>
                    <td>Umum</td>
                    <td>BANK TRA...</td>
                    <td align="right">105,000</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>SEPHIA ANG...</td>
                    <td>Umum</td>
                    <td>BANK TRA...</td>
                    <td align="right">105,000</td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right"><strong>420,000</strong></td>
                </tr>
            </tbody>
        </table>

        Resume
        <table width="100%" style="font-size: small">
            <tbody>
                <tr>
                    <td>Give Away</td>
                    <td>: 1</td>
                </tr>
                <tr>
                    <td>Umum</td>
                    <td>: 4</td>
                </tr>
            </tbody>
        </table>
        <br>
        <table width="100%" style="font-size: small">
            <tbody>
                <tr>
                    <td>CASH PAYMENT</td>
                    <td align="right"> <strong>0</strong></td>
                </tr>
                <tr>
                    <td>BANK TRANSFER</td>
                    <td align="right"> <strong>420,000</strong></td>
                </tr>
            </tbody>
        </table>
        <hr>
        <strong><small>PAKET</small></strong>
        <table width="100%" style="font-size: small">
            <tbody>
                <tr style="font-weight: bold">
                    <td>Pnrma</td>
                    <td>Paket</td>
                    <td>KG/Koli</td>
                    <td>Bayar</td>
                    <td>Jumlah</td>
                </tr>

                <tr>
                    <td></td>
                    <td>Kosong</td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td align="right">
                        <strong>
                            0
                        </strong>
                    </td>
                </tr>
            </tbody>
        </table>

        Resume
        <table width="100%" style="font-size: small">
            <tbody>
                <tr>
                    <td>Kosong</td>
                    <td></td>
                </tr>
            </tbody>
        </table>

        <hr>
        <br>

        <table width="100%" style="font-size: small">
            <tbody>
                <tr>
                    <td align="center">
                        CSO<br><br><br>
                        Jhon Erastus
                    </td>

                    <td align="center">
                        Sopir <br><br><br>
                        Iyan suryana
                    </td>
                </tr>
            </tbody>
        </table>



    </div>


</body>

</html>