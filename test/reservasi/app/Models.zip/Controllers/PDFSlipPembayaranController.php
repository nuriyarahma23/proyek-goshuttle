<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Database\Migrations\Paket;
use App\Models\DiskonModel;
use App\Models\KotaModel;
use App\Models\KursipenumpangModel;
use App\Models\PaketModel;
use App\Models\PembayaranModel;
use App\Models\ReservasiModel;
use Dompdf\Dompdf;

class PDFSlipPembayaranController extends BaseController
{
    public function index()
    {
        //
    }
    public function pdfreservasi($id_kursi)
    {
        $logoPath = base_url('logo_go_1.png');
        // $logoData = file_get_contents($logoPath);
        // $logoBase64 = base64_encode($logoData);


        $kursiReservasiModel = new KursipenumpangModel();
        $kursiReservasiData = $kursiReservasiModel->find($id_kursi);


        $tiketModel = new ReservasiModel();
        $tiketData = $tiketModel->find($kursiReservasiData['id_reservasi']);
        $kotaModel = new KotaModel();
        $kotaData = $kotaModel->findAll();
        $kotagrouping = [];
        foreach ($kotaData as $kd) {
            $kotagrouping[$kd['kode_kota']] = $kd;
        }

        $pembayaranModel = new PembayaranModel();
        $pembayaranData = $pembayaranModel->where('id_kursi', $kursiReservasiData['id_kursi'])->first();



        $diskonModel = new DiskonModel();
        $diskonData = $diskonModel->find($kursiReservasiData['id_diskon']);
        $diskonData1 = [];
        foreach ($diskonData as $diskondt) {
            $diskonData1[$diskondt['id_diskon']] = $diskondt;
        }
      
        $data = [
            'logo' => $logoPath,
            'tiketData' => $tiketData,
            'kodekota' => $kotagrouping,
            'kursiReservasiData' => $kursiReservasiData,
            'pembayaranData' => $pembayaranData,
            'diskon' => $diskonData1
        ];


        return view('pdf/slippembayaran', $data);


        // $dompdf = new Dompdf();
        // $dompdf->loadHtml(view("pdf/slippembayaran", $data));
        // $dompdf->set_option('isHtml5ParserEnabled', true);
        // // $dompdf->set_option('isRemoteEnabled', true);

        // $dompdf->setPaper('A4', 'portrait');
        // $dompdf->render();
        // $dompdf->stream('struk_pembayaran.pdf', ['Attachment' => 0]);
    }


    public function pdfreservasipaket($id_paket)
    {
        $logoPath = base_url('logo_go_1.png');


        $paketModel = new PaketModel();
        $paketData = $paketModel->find($id_paket);


        $tiketModel = new ReservasiModel();
        $tiketData = $tiketModel->find($paketData['id_reservasi']);
        $kotaModel = new KotaModel();
        $kotaData = $kotaModel->findAll();
        $kotagrouping = [];
        foreach ($kotaData as $kd) {
            $kotagrouping[$kd['kode_kota']] = $kd;
        }

        // $pembayaranModel = new PembayaranModel();
        // $pembayaranData = $pembayaranModel->where('id_kursi', $kursiReservasiData['id_kursi'])->first();

        $data = [
            'logo' => $logoPath,
            'tiketData' => $tiketData,
            'kodekota' => $kotagrouping,
            'paketData' => $paketData,
            // 'pembayaranData' => $pembayaranData
        ];


        return view('pdf/slippembayaranpaket', $data);


        // $dompdf = new Dompdf();
        // $dompdf->loadHtml(view("pdf/slippembayaran", $data));
        // $dompdf->set_option('isHtml5ParserEnabled', true);
        // // $dompdf->set_option('isRemoteEnabled', true);

        // $dompdf->setPaper('A4', 'portrait');
        // $dompdf->render();
        // $dompdf->stream('struk_pembayaran.pdf', ['Attachment' => 0]);
    }
    public function pdfmanifest($id_reservasi)
    {
        $logoPath = base_url('logo_go_1.png');
        // $logoData = file_get_contents($logoPath);
        // $logoBase64 = base64_encode($logoData);


        $kursiReservasiModel = new KursipenumpangModel();
        $kursiReservasiData = $kursiReservasiModel->find($id_reservasi);


        $tiketModel = new ReservasiModel();
        $tiketData = $tiketModel->find($kursiReservasiData['id_reservasi']);
        $kotaModel = new KotaModel();
        $kotaData = $kotaModel->findAll();
        $kotagrouping = [];
        foreach ($kotaData as $kd) {
            $kotagrouping[$kd['kode_kota']] = $kd;
        }

        $pembayaranModel = new PembayaranModel();
        $pembayaranData = $pembayaranModel->where('id_kursi', $kursiReservasiData['id_kursi'])->first();

        $data = [
            'logo' => $logoPath,
            'tiketData' => $tiketData,
            'kodekota' => $kotagrouping,
            'kursiReservasiData' => $kursiReservasiData,
            'pembayaranData' => $pembayaranData
        ];


        return view('pdf/pdfmanifest', $data);
    }
}
